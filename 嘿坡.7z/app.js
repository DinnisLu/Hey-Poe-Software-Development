// app.js
App({
  onLaunch() {
    
    //云开发环境的初始化
    wx.cloud.init({
      env:"cloud1-2g8mb50x10c0a849"
      //env: 'sdenv1-7g7ypfuq46e52b1b'
    })

    if(wx.getStorageSync('userInfo')){
      this.globalData.userInfo = wx.getStorageSync('userInfo')
    }
    


  },
  globalData: {
    userInfo: null
  }
})
