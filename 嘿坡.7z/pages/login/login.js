// index.js
// 获取应用实例
const app = getApp()

Page({
  data: {
   
  },

  onLoad() {
   
  },
  toZc(){
    wx.navigateTo({
      url: '/pages/index/index',
    })
  },

  getZh(e){
    console.log(e.detail.value)
    this.setData({
      zh: e.detail.value
    })
  },
  getPassword(e){
    console.log(e.detail.value)
    this.setData({
      ps: e.detail.value
    })
  },


  login(){
    if(!this.data.zh){
      wx.showToast({
        icon:'none',
        title: '请输入账号',
      })
      return
    }
    if(!this.data.ps){
      wx.showToast({
        icon:'none',
        title: '请输入密码',
      })
      return
    }
    
    var that = this;
    wx.cloud.database().collection('chat_users').where({
        admin:that.data.zh,
        password:that.data.ps
    }).get({
      success(res){
        console.log(res)
        if(res.data.length>0){

          app.globalData.userInfo = res.data[0]

          wx.setStorageSync('userInfo', res.data[0])

          wx.switchTab({
            url: '/pages/me/me',
            success(){
              wx.showToast({
                title: '登录成功！',
              })
            }
          })

          
        }else{
          wx.showToast({
            icon:'none',
            title: '账号密码错误',
          })
        }
      }
    })




  }
 
})
