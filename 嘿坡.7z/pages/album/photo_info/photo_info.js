// pages/album/photo_info/photo_info.js
const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    photo: null
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.getInfo()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },

  getInfo() {
    wx.cloud.database().collection("photo")
    .where({
      ownerId: app.globalData.userInfo.num
    }).get()
    .then(res => {
      var data = res.data[0]
      var info = {
        "_id": data._id,
        "name": data.name,
        "sex": data.sex,
        "age": this.getAge(data.birthday),
        "birthday": data.birthday,
        "school": data.school,
        "intrest": data.intrest,
        "preference": data.preference,
        "profilePhoto": data.profilePhoto
      }
      this.setData({
        photo: info
      })
    })
  },

  getAge(birthday) {
    var date = new Date(birthday)
    var now = new Date()
    var age = now.getFullYear() - date.getFullYear()
    return age
  }
})