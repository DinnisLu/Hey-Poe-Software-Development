// pages/album/album.js
const app = getApp()
const db = wx.cloud.database()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    queryStep: 0, // 取数据的次数
    photoSeq: [], // 将显示到页面的照片序列
    maxSeqSize: 20, // (<=20)
    curIndex: 0, // 当前显示的照片下标
    images: [],
    next: null,

    likeQuantity: 0,
    likeBtn: "dislike"
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.checkInit()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    this.getPhotos()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },

  async checkInit() {
    await db.collection("photo").where({"ownerId": app.globalData.userInfo.num})
    .get()
    .then(res => {
      if (res.data.length == 0) {
        wx.redirectTo({
          url: './photo_init/photo_init',
          success: (res) => {},
          fail: (res) => {},
          complete: (res) => {},
        })
      }
    })
  },

  // imagePreview() {
  //   wx.previewImage({
  //     current: this.data.images[0],
  //     urls: this.data.images
  //   })
  // },

  getPhotos() {
    // 预留位置，需要完成排除本人photo，按本人photo的preference选择显示的photo
    var myId = app.globalData.userInfo.num
    db.collection("photo").where({"ownerId": myId})
    .get()
    .then(res => {
      // 查询步数重置
      if (res.data.length == 0) {
        this.setData({
          queryStep: 1
        })
      }

      if (res.data[0].preference == "随意") {
        db.collection("photo").skip(this.data.queryStep * this.data.maxSeqSize)
        .get()
        .then(res => {
          var records = []
          for (var i = 0; i < res.data.length; i++) {
            if (res.data[i].ownerId != myId) {
              records.push(res.data[i])
            }
          }
          this.setData({
            photoSeq: records
          })
          this.getMyLike()
          this.getLikeQuantity()
        })
      } else {
        db.collection("photo").skip(this.data.queryStep * this.data.maxSeqSize)
        .where({
          "sex": res.data[0].preference
        }).get()
        .then(res => {
          var records = []
          for (var i = 0; i < res.data.length; i++) {
            if (res.data[i].ownerId != myId) {
              records.push(res.data[i])
            }
          }
          this.setData({
            photoSeq: records
          })
          this.getMyLike()
          this.getLikeQuantity()
        })
      }
    })
  },

  /**
   * 刷新当前照片like数量
   */
  getLikeQuantity() {
    db.collection("like_record")
    .where({
      "photo_ownerId": this.data.photoSeq[this.data.curIndex].ownerId
    }).count().then(res => {
      this.setData({
        likeQuantity: res.total
      })
    })
  },

  getMyLike() {
    db.collection("like_record")
    .where({
      "like_ownerId": app.globalData.userInfo.num,
      "photo_ownerId": this.data.photoSeq[this.data.curIndex].ownerId
    }).get().then(res  => {
      this.setData({
        likeBtn: res.data.length == 0 ? "dislike" : "like"
      })
    })
  },

  /**
   * like照片，点击like按钮之后调用
   * 如果存在本用户的like记录则删除，否则添加like记录，并更新likeBtn为相应状态
   */
  async like() {
    await db.collection("like_record")
    .where({
      "like_ownerId": app.globalData.userInfo.num,
      "photo_ownerId": this.data.photoSeq[this.data.curIndex].ownerId
    }).get().then(res => {
      if (res.data.length == 0) { // like不存在，添加like
        db.collection("like_record").add({
          data: {
            "photo_ownerId": this.data.photoSeq[this.data.curIndex].ownerId, // 取当前显示照片ownerId
            "like_ownerId": app.globalData.userInfo.num
          }
        }).then(res => {
          this.setData({
            likeBtn: "like"
          })
          this.getLikeQuantity()
          wx.showToast({
            title: 'like',
          })
        })
      } else { // like存在，删除like
        db.collection("like_record").doc(res.data[0]._id).remove()
        .then(res => {
          this.setData({
            likeBtn: "dislike"
          })
          this.getLikeQuantity()
          wx.showToast({
            title: 'dislike',
          })
        })
      }
    })
  },

  /**
   * 按钮翻页，点击next按钮调用
   * 通过设置自动翻页翻到下一页
   * 如果翻到最后一页则刷新照片序列的照片
   */
  next() {
    if (this.data.curIndex == this.data.photoSeq.length - 1) {
      this.getPhotos()
    }
    this.setData({
      next: true
    })
  },

  /**
   * 翻页更新绑定函数
   * 翻页时关闭自动翻页，更新当前页号和like数
   * @param {*} e 
   */
  change(e) {
    this.setData({
      next: null,
      curIndex: e.detail.current
    })
    this.getMyLike()
    this.getLikeQuantity()
  },

  myPhoto() {
    wx.redirectTo({
      url: './photo_info/photo_info',
    })
  }
})