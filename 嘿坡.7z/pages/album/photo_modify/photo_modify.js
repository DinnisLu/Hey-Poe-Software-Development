// pages/album/photo_modify/photo_modify.js
const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    _id: "",

    // cropper
    src:'',
    width:250,//宽度
    height: 250,//高度
    cropperDisplay: "none",
    
    // uploadimage
    imageChange: false,
    cutPath: "", // 裁剪后的文件路径
    uploadPath: "", // 上传文件后的fileID

    // form
    schools: [
      "会计学院",
      "金融与经济学院",
      "管理学院",
      "信息工程学院",
      "法学院",
      "艺术与传媒学院",
      "外国语学院",
      "马克思主义学院"
    ],
    intrests: [
      "户外",
      "学习",
      "美食",
      "社交",
      "运动",
      "游戏动漫",
      "电影",
      "音乐",
      "摄影",
      "艺术"
    ],
    birthday: "",
    school: "",
    intrest: "",

    name: "",
    sexChecked: "",
    preferenceChecked: "",
    profilePhoto: ""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.infoInit(options)
    this.cropperInit()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },

  infoInit(photo) {
    this.setData({
      _id: photo._id,
      name: photo.name,
      sexChecked: photo.sex,
      birthday: photo.birthday,
      school: photo.school,
      intrest: photo.intrest,
      preferenceChecked: photo.preference,
      profilePhoto: photo.src,
      cutPath: photo.src
    })
  },

  // cropper
  cropperInit() {
    this.cropper = this.selectComponent("#image-cropper")
  },
  cropperload(e){
    
  },
  loadimage(e){
      //重置图片角度、缩放、位置
      this.cropper.imgReset();
  },
  clickcut(e) {
      this.setData({
        cutPath: e.detail.url,
        cropperDisplay: "none"
      })
  },



  // form
  selectBirthday(e) {
    this.setData({
      birthday: e.detail.value
    })
  },

  selectSchool(e) {
    this.setData({
      school: this.data.schools[e.detail.value]
    })
  },

  selectIntrest(e) {
    this.setData({
      intrest: this.data.intrests[e.detail.value]
    })
  },

  async update(e) {
    console.log("in up")
    var {name, sex, birthday, school, intrest, preference} = e.detail.value

    if (name == "" || sex == "" || birthday == "" || school == ""
    || intrest == "" || preference == "") {
      wx.showToast({
        icon: "error",
        title: '信息不完整'
      })
      return
    }

    if (this.data.imageChange) {
      await this.uploadImg() // 图片在其他校验之后提交
    } else {
      this.setData({
        uploadPath: this.data.src
      })
    }

    // 数据校验
    if (this.data.uploadPath == "") {
      wx.showToast({
        icon: "error",
        title: '请上传头像'
      })
      return
    }
    // 数据更新
    wx.cloud.database().collection("photo").doc(this.data._id).update({
      data: {
        ownerId: app.globalData.userInfo.num,
        name: name,
        sex: sex,
        birthday: birthday,
        school,
        intrest: intrest,
        preference: preference,
        profilePhoto: this.data.uploadPath
      }
    }).then(
      wx.redirectTo({
        url: '../photo_info/photo_info',
      })
    )
  },

  chooseImg() {
    wx.chooseMedia({
      count: 1,
      mediaType: "image",
      sourceType: ["album", "camera"],
      success: res => {
        this.setData({
          imageChange: true,
          src: res.tempFiles[0].tempFilePath,
          cropperDisplay: "display"
        })
      }
    })
  },

  async uploadImg() {
    await wx.cloud.uploadFile({
      cloudPath: "upload/image/"+Date.now()+".png",
      filePath: this.data.cutPath
    }).then(res => {
      this.deleteImg(this.data.profilePhoto)
      this.setData({
        uploadPath: res.fileID
      })
    })
  },

  deleteImg(fileID) {
    console.log(fileID)
    wx.cloud.deleteFile({
      fileList: [
        fileID
      ],
      success: res => {
        console.log(res.fileList)
      },
      fail: err => {
        console.error(err)
      },
    })
  }
})
