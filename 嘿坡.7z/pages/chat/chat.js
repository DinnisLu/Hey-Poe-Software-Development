const util = require("../../utils/util")
const app = getApp()
Page({

  data: {

  },
  onShow(){
    this.setData({
      userInfo: app.globalData.userInfo
    })
  },
  onLoad: function (options) {
    console.log(options.id)
    this.setData({
      recordId:options.id
    })

    this.getChatRecord()


  },

  getChatRecord(){

    var that = this;
    wx.cloud.database().collection('chat_record').doc(that.data.recordId).get({
      success(res){
        console.log(res)
        that.setData({
          chatList: res.data.record
        })
      }
    })
  },


  getInputValue(event){

    console.log(event.detail.value)

    this.data.inputValue = event.detail.value
    
  },
  publishChat(){
    var that = this;
    wx.cloud.database().collection('chat_record').doc(that.data.recordId).get({
      success(res){
        console.log(res)


        var record = res.data.record
        var msg = {}
        msg.userId = app.globalData.userInfo._id
        msg.nickName = app.globalData.userInfo.nickName
        msg.faceImg = app.globalData.userInfo.faceImg
        msg.openid = app.globalData._id
        msg.text = that.data.inputValue
        msg.time = util.formatTime(new Date())

        record.push(msg)

        wx.cloud.database().collection('chat_record').doc(that.data.recordId).update({
          data: {
            record: record
          },
          success(res){
            console.log(res)
            wx.showToast({
              title: '发布成功！',
            })
            
            //刷新下
            that.getChatRecord()

            that.setData({
              inputValue :'',
              plcaceHolder:'评论'
            })
          }
        })


      }
    })

    


  },
})