const app = getApp()
Page({


  data: {
    orderList: [],
    orderCount: 0,
    selectedType: [false, false, false, false, false, false, false],
    itemsStyle: "folded_items",
    displayData: {
      type: "",
      detial: "",
      name: "",
      phone: 0
    },
    curOrder: null
  },
  onShow(){
    this.setData({
      userInfo:app.globalData.userInfo
    })
    this.getAllRecords("history", "orderList") // 获取history全部订单，并筛选
  },
  
  onLoad: function (options) {
    
  },
  toLogin(){
    wx.navigateTo({
      url: '/pages/login/login',
    })
  },
   tolishi(){
    wx.navigateTo({
      url: '/pages/lishi/lishi',
    })
  },
  toCancel(){
    wx.navigateTo({
      url: '/pages/Cancel/Cancel',
    })
  },
  
  todindan(){
    wx.navigateTo({
      url: '/pages/dindan/dindan',
    })
  },

  todescription(){
    wx.navigateTo({
      url: '/pages/description/description',
    })
  },

  /**
   * 根据实际订单数量调整显示订单数量
   */
  refreshOrderCount() {
    this.setData({
      orderCount: this.data.orderList.length >= 3 ? 3 : this.data.orderList.length
    })
  },

  /**
   * 数据库获取集合collectionName中的所有记录，存入listName数组
   * @param {string} collectionName 
   * @param {string} listName 
   */ 
  getAllRecords(collectionName, listName) {
    // 清空
    this.setData({
      orderList: []
    })
    let LIMIT = 20
    wx.cloud.database().collection(collectionName).count()
      .then(res => {
        var bactchTimes = Math.ceil(res.total / LIMIT) // 计算取数据次数
        for (var i = 0; i < bactchTimes; i++) {
          wx.cloud.database().collection(collectionName).skip(i * LIMIT)
          .where({
            "userId": app.globalData.userInfo.num
          })
          .get()
            .then(res => {
              var records = res.data
              // 更新显示订单
              this.setData({
                [listName]: this.data[listName].concat(records)
              })
              // 调整订单显示数量
              this.refreshOrderCount()
            })
        }
      })
  },

  /**
   * 选择marker的显示订单类型
   * @param {number} no 
   */
  setType(no) {
    var ss = [false, false, false, false, false, false, false]
    ss[no] = true
    this.setData({
      selectedType: ss,
      itemsStyle: "items"
    })
  },

  /**
   * 隐藏显示的详细数据
   */
  hideTypes() {
    this.setData({
      selectedType: [false, false, false, false, false, false, false],
      itemsStyle: "folded_items"
    })
  },

  /**
   * 将类型字符串转换为对应类型编号
   * @param {string} type 
   */
  mapTypeToNo(type) {
    let map = {
      "旧货交易": 0, "校外代购": 1, "线上类": 2, "综合服务": 3, "兼职专区": 4,
      "学校公益专区": 5, "其他": 6
    }
    return map[type]
  },

  /**
   * 判断当前是否存在显示的详细数据
   */
  hasDisplayType() {
    for (var i = 0; i < this.data.selectedType.length; i++) {
      if (this.data.selectedType[i]) {
        return true
      }
    }
    return false
  },
 
  /**
   * 显示或隐藏点击的Marker详细数据
   * @param {Event} e 
   */
  displayDetail(e) {
    let order = e.currentTarget.dataset.order
    if (this.data.curOrder !== null && this.data.curOrder._id === order._id && this.hasDisplayType()) {
      this.hideTypes()
      this.setData({
        curOrder: order
      })
    }
    else {
      let no = this.mapTypeToNo(order["type"])
      this.setType(no)
      this.setData({
        displayDetail: {
          type: order.type,
          detail: order.detail,
          name: order.name,
          phone: order.phone
        },
      })
      this.setData({
        curOrder: order
      })
    }
  }
})