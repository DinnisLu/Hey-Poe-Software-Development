// index.js
// 获取应用实例
const app = getApp()

Page({
  data: {
   
  },

  onLoad() {
   
  },

  getUserProfile(e) {
    
    var that = this;
    wx.getUserProfile({
      desc: '展示用户信息', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
      success: (res) => {
        console.log(res)
        that.setData({
          userInfo: res.userInfo
  
        })
      }
    })
    
  },

  getZh(e){
    console.log(e.detail.value)
    this.setData({
      zh: e.detail.value
    })
  },
  getPassword(e){
    console.log(e.detail.value)
    this.setData({
      ps1: e.detail.value
    })
  },
  getPassword2(e){
    console.log(e.detail.value)
    this.setData({
      ps2: e.detail.value
    })
  },

  zhuce(){
   
    if(!this.data.userInfo){
      wx.showToast({
        icon:'none',
        title: '请授权微信信息',
      })
      return
    }
    if(this.data.ps1 == '' || this.data.ps1 == undefined){
      wx.showToast({
        icon:'none',
        title: '请输入密码',
      })
      return
    }
    if(this.data.ps1 != this.data.ps2){
      wx.showToast({
        icon:'none',
        title: '密码不相同',
      })
      return
    }
    console.log(Date.now())
    var that = this;
    wx.cloud.database().collection('chat_users').add({
      data:{
        num: Date.now(),//账号
        faceImg: that.data.userInfo.avatarUrl,
        nickName: that.data.userInfo.nickName,
        admin: that.data.zh,
        password: that.data.ps1
      },
      success(res){
        console.log(res)
        wx.cloud.database().collection('chat_users').doc(res._id).get({
          success(res){
            console.log(res)
            app.globalData.userInfo = res.data

            wx.setStorageSync('userInfo', res.data)

            wx.switchTab({
              url: '/pages/me/me',
              success(){
                wx.showToast({
                  title: '注册成功',
                })
              }
            })

          }
        })

        
        

      }
    })
  }
 
})
