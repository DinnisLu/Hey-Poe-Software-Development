// pages/demand_list/demand_list.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    pageType: {
      0: ["旧货交易", "旧货交易需求列表"],
      1: ["校外代购", "校外代购需求"],
      2: ["线上类", "线上需求"],
      3: ["综合服务", "综合服务需求"],
      4: ["兼职专区", "兼职需求"],
      5: ["学校公益专区", "学校公益需求"],
      6: ["其他", "其他需求"]
    },
    latitude: 0,
    longitude: 0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
 
    this.locate()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },

  /**
   * 页面跳转
   * @param {Event} e 
   */
  goToPage(e) {
    wx.redirectTo({
      url: e.currentTarget.dataset.url
    })
  },

  /**
   * 需要服务和提供服务订单切换
   * @param {Event} e 
   */
  goToPageWithData(e) {
    let data = {
      pageType: this.data.pageType[e.currentTarget.dataset.value],
      pos: {
        latitude: this.data.latitude,
        longitude: this.data.longitude
      }
    }
    wx.redirectTo({
      url: e.currentTarget.dataset.url+"?data="+JSON.stringify(data)
    })
  },

  /**
   * 获取定当前位
   */
  locate() {
    wx.getLocation({
      altitude: 'true',
      type: 'gcj02'
    }).then(res =>{
      this.setData({
        latitude: res.latitude,
        longitude: res.longitude
      })
    })
  }
})