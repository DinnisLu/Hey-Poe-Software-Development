// pages/lishi/lishi.js
const app = getApp()
Page({

  
  data: {
    orderList: [],
    orderCount: 0,
    selectedType: [false, false, false, false, false, false, false],
    itemsStyle: "folded_items",
    displayData: {
      type: "",
      detial: "",
      name: "",
      phone: 0
    },
    curOrder: null
  },
  
  /**
   * 页面的初始数据
   */
 

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    this.setData({
      userInfo:app.globalData.userInfo
    })
    this.getAllRecords("finished", "orderList") // 获取history全部订单，并筛选
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },

  
  /**
   * 根据实际订单数量调整显示订单数量
   */
  refreshOrderCount() {
    this.setData({
      orderCount: this.data.orderList.length >= 3 ? 3 : this.data.orderList.length
    })
  },

  /**
   * 数据库获取集合collectionName中的所有记录，存入listName数组
   * @param {string} collectionName 
   * @param {string} listName 
   */ 
  getAllRecords(collectionName, listName) {
    // 清空
    this.setData({
      orderList: []
    })
    let LIMIT = 20
    wx.cloud.database().collection(collectionName).count()
      .then(res => {
        var bactchTimes = Math.ceil(res.total / LIMIT) // 计算取数据次数
        for (var i = 0; i < bactchTimes; i++) {
          wx.cloud.database().collection(collectionName).skip(i * LIMIT)
          .where({
            "userId": app.globalData.userInfo.num
          })
          .get()
            .then(res => {
              var records = res.data
              // 更新显示订单
              this.setData({
                [listName]: this.data[listName].concat(records)
              })
              // 调整订单显示数量
              this.refreshOrderCount()
            })
        }
      })
  },

  /**
   * 选择marker的显示订单类型
   * @param {number} no 
   */
  setType(no) {
    var ss = [false, false, false, false, false, false, false]
    ss[no] = true
    this.setData({
      selectedType: ss,
      itemsStyle: "items"
    })
  },

  /**
   * 隐藏显示的详细数据
   */
  hideTypes() {
    this.setData({
      selectedType: [false, false, false, false, false, false, false],
      itemsStyle: "folded_items"
    })
  },

  /**
   * 将类型字符串转换为对应类型编号
   * @param {string} type 
   */
  mapTypeToNo(type) {
    let map = {
      "旧货交易": 0, "校外代购": 1, "线上类": 2, "综合服务": 3, "兼职专区": 4,
      "学校公益专区": 5, "其他": 6
    }
    return map[type]
  },

  /**
   * 判断当前是否存在显示的详细数据
   */
  hasDisplayType() {
    for (var i = 0; i < this.data.selectedType.length; i++) {
      if (this.data.selectedType[i]) {
        return true
      }
    }
    return false
  },
 
  /**
   * 显示或隐藏点击的Marker详细数据
   * @param {Event} e 
   */
  displayDetail(e) {
    let order = e.currentTarget.dataset.order
    if (this.data.curOrder !== null && this.data.curOrder._id === order._id && this.hasDisplayType()) {
      this.hideTypes()
      this.setData({
        curOrder: order
      })
    }
    else {
      let no = this.mapTypeToNo(order["type"])
      this.setType(no)
      this.setData({
        displayDetail: {
          type: order.type,
          detail: order.detail,
          name: order.name,
          phone: order.phone
        },
      })
      this.setData({
        curOrder: order
      })
    }
  },

  deleteRecord() {
    let id = this.data.curOrder._id
    // 添加历史数据
    var record = this.deepCopy(this.data.curOrder)
    delete record["_id"]
    delete record["_openid"]
    record["userId"] = app.globalData.userInfo.num
    wx.cloud.database().collection("finished")
    .add({
      data: record
    })
    // 数据库删除
    wx.cloud.database().collection("history").doc(id).remove()
    // marker删除
    // var nMarkers = this.deepCopy(this.data.markers)
    // delete nMarkers[this.data.curMarkerId]
    // this.setData({
    //   markers: nMarkers,
    //   curMarkerId: -1
    // })
    this.hideTypes()
    wx.showToast({
      title: '接单成功',
      duration: 1000,
      success: function() {
        setTimeout(function() {
          wx.redirectTo({
            url: '../me/me',
          })
        }, 1000)
      }
    })
  },

  /**
   * 对数组或对象进行深拷贝，obj为对象或数组
   * @param {Object} obj 
   * @returns {Object}
   */
  deepCopy(obj) {
    var nObj = obj.constructor === Array ? [] : {}
    for (let i in obj) {
      if (typeof (obj[i]) === "object") {
        nObj[i] = this.deepCopy(obj[i])
      } else {
        nObj[i] = obj[i]
      }
    }
    return nObj
  }
})