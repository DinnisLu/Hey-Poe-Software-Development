// pages/map/map.js
const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    records: [],
    lat: 0,
    lng: 0,
    map: true,
    markers: [],
    selectedType: [false, false, false, false, false, false, false],
    itemsStyle: "folded_items",
    displayData: {
      type: "",
      detial: "",
      name: "",
      phone: 0
    },
    curMarkerId: -1
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {
    this.mapCtx = wx.createMapContext('hpmap')
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    this.pageUpdate()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },

  /**
   * 页面更新
   */
  pageUpdate() {
    var initData = wx.getStorageSync('mapInitData')
    if (initData) {
      wx.removeStorageSync('mapInitData')
      this.setData({
        lat: initData["latitude"],
        lng: initData["longitude"]
      })
    }
    else {
      wx.startLocationUpdate({
        success: (res) => {
          wx.onLocationChange((result) => {
            this.setData({
              lat: result.latitude,
              lng: result.longitude
            })
            console.log(this.data.lat)
            console.log(this.data.lng)
            wx.stopLocationUpdate({
              success: (res) => { },
            })
          })
        },
      })
      //暂时保留
      // wx.getLocation({
      //   altitude: 'altitude',
      //   type: 'gcj02'
      // }).then(res => {
      //   this.setData({
      //     lat: res.latitude,
      //     lng: res.longitude
      //   })
      // })
    }
    this.getAllRecords("222")
  },

  /**
   * 页面跳转到主菜单
   */
  goToMenuPage(e) {
    wx.redirectTo({
      url: e.currentTarget.dataset.url,
    })
  },

  /**
   * 按经纬度和显示文本创建marker，并添加到marker显示数组markers
   * @param {number} lat 
   * @param {number} lng 
   * @param {string} text 
   */
  createMarker(lat, lng, text) {
    var _markers = []
    if (this.data.markers.length !== 0) {
      this.data.markers.forEach(elm => {
        _markers.push(elm)
      })
    }
    _markers.push({
      id: _markers.length,
      iconPath: "cloud://cloud1-2g8mb50x10c0a849.636c-cloud1-2g8mb50x10c0a849-1311760990/images/hpOne/标记@3x.png",
      latitude: lat,
      longitude: lng,
      width: 50,
      height: 50,
      label: {
        content: text,
        anchorX: -((text.length * 10)/2),
        anchorY: 3,
        bgColor: "#CCCCCC",
        borderRadius: 5,
        fontSize: 10,
        padding: 3
      }
    })
    this.setData({
      markers: _markers
    })
  },

  /**
   * 获取云数据库中的集合collectionName中的所有记录
   * @param {string} collectionName 
   */
  getAllRecords(collectionName) {
    let LIMIT = 20
    wx.cloud.database().collection(collectionName).count()
      .then(res => {
        var bactchTimes = Math.ceil(res.total / LIMIT)
        for (var i = 0; i < bactchTimes; i++) {
          wx.cloud.database().collection(collectionName).skip(i * LIMIT).get()
            .then(res => {
              this.setData({
                records: this.data.records.concat(res.data)
              })
              res.data.forEach(elm => {
                this.createMarker(elm.latitude, elm.longitude, elm.type)
              })
            })
        }
      })
  },

  /**
   * 根据id获取marker对应订单数据
   * @param {number} markerId 
   */
  getMarkerData(markerId) {
    return this.data.records[markerId]
  },

  /**
   * 选择marker的显示订单类型
   * @param {number} no 
   */
  setType(no) {
    var ss = [false, false, false, false, false, false, false]
    ss[no] = true
    this.setData({
      selectedType: ss,
      itemsStyle: "items"
    })
  },

  /**
   * 隐藏显示的详细数据
   */
  hideTypes() {
    this.setData({
      selectedType: [false, false, false, false, false, false, false],
      itemsStyle: "folded_items"
    })
  },

  /**
   * 将类型字符串转换为对应类型编号
   * @param {string} type 
   */
  mapTypeToNo(type) {
    let map = {
      "旧货交易": 0, "校外代购": 1, "线上类": 2, "综合服务": 3, "兼职专区": 4,
      "学校公益专区": 5, "其他": 6
    }
    return map[type]
  },

  /**
   * 判断当前是否存在显示的详细数据
   */
  hasDisplayType() {
    for (var i = 0; i < this.data.selectedType.length; i++) {
      if (this.data.selectedType[i]) {
        return true
      }
    }
    return false
  },

  /**
   * 显示或隐藏点击的Marker详细数据
   * @param {Event} e 
   */
  displayDetail(e) {
    let id = e.detail.markerId
    if (this.data.curMarkerId == id && this.hasDisplayType()) {
      this.hideTypes()
      this.setData({
        curMarkerId: -1
      })
    }
    else {
      let markerData = this.getMarkerData(id)
      let no = this.mapTypeToNo(markerData["type"])
      this.setType(no)
      this.setData({
        displayDetail: {
          type: markerData.type,
          detail: markerData.detail,
          name: markerData.name,
          phone: markerData.phone
        },
      })
      this.setData({
        curMarkerId: id
      })
    }
  },

  /**
   * 删除选定marker对应订单
   */
  deleteRecord() {
    if (this.data.curMarkerId == -1) return
    let id = this.data.records[this.data.curMarkerId]._id
    // 添加历史数据
    var record = this.deepCopy(this.data.records[this.data.curMarkerId])
    delete record["_id"]
    delete record["_openid"]
    record["userId"] = app.globalData.userInfo.num
    wx.cloud.database().collection("history")
    .add({
      data: record
    })
    // 数据库删除
    wx.cloud.database().collection("222").doc(id).remove()
    // marker删除
    // var nMarkers = this.deepCopy(this.data.markers)
    // delete nMarkers[this.data.curMarkerId]
    // this.setData({
    //   markers: nMarkers,
    //   curMarkerId: -1
    // })
    this.hideTypes()
    wx.showToast({
      title: '接单成功',
      duration: 1000,
      success: function() {
        setTimeout(function() {
          wx.redirectTo({
            url: '../me/me',
          })
        }, 1000)
      }
    })
  },

  /**
   * 对数组或对象进行深拷贝，obj为对象或数组
   * @param {Object} obj 
   * @returns {Object}
   */
  deepCopy(obj) {
    var nObj = obj.constructor === Array ? [] : {}
    for (let i in obj) {
      if (typeof (obj[i]) === "object") {
        nObj[i] = this.deepCopy(obj[i])
      } else {
        nObj[i] = obj[i]
      }
    }
    return nObj
  }
})