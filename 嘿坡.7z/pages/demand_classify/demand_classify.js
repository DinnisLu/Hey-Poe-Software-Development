// pages/demand_classify/demand_classify.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    pageType: "",
    pageDesc: "",
    pos: {},
    records: [],
    classifiedRecords: {},
    orderList: [],
    typeList: [],
    select: ["selected", ""],
    listState: "type_list_hidden",
    orderCount: 0,
    typeCount: 0,
    isDesc: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.setData({
      pageType: JSON.parse(options.data)["pageType"][0],
      pageDesc: JSON.parse(options.data)["pageType"][1],
      pos: JSON.parse(options.data)["pos"]
    })
    this.refreshTypeList()
    this.refreshRecordList()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },

  /**
   * 页面跳转
   * @param {Event} e
   */
  goToPage(e) {
    wx.switchTab({
      url: e.currentTarget.dataset.url
    })
  },

  /**
   * 跳转页面时携带数据
   * @param {Event} e
   */
  goToPageWithData(e) {
    wx.setStorageSync('mapInitData', e.currentTarget.dataset.value)
    wx.switchTab({
      url: e.currentTarget.dataset.url
    })
  },

  /**
   * 切换排序方式，降序或升序
   */
  switchSortMethod() {
    this.setData({
      isDesc: !this.data.isDesc
    })
  },

  /**
   * 需要服务和提供服务订单切换
   * @param {Event} e 
   */
  selectItem(e) {
    if (e.currentTarget.dataset.value === "provide") {
      this.setData({
        select: ["selected", ""]
      })
    }
    else {
      this.setData({
        select: ["", "selected"]
      })
    }
    this.refreshOrderList(this.data.pageType)
  },

  /**
   * 切换类型列表显隐状态
   * 已弃用，请勿使用，也不要删除
   * @deprecated
   */
  switchListState() {
    if (this.data.listState === "type_list_hidden") {
      this.setData({
        listState: "type_list"
      })
    }
    else {
      this.setData({
        listState: "type_list_hidden"
      })
    }
  },

  /**
   * 切换显示订单类型
   * 已弃用，请勿使用，也不要删除
   * @deprecated
   * @param {Event} e 
   */
  switchOrderType(e) {
    let type = e.currentTarget.dataset["type"]
    this.refreshOrderList(type)
    this.switchListState()
  },

  /**
   * 订单列表按金额排序
   */
  sortOrderList() {
    this.switchSortMethod()
    var list = this.deepCopy(this.data.orderList)
    if (this.data.isDesc) {
      for (var i = 0; i < list.length - 1; i++) {
        var min = 0
        for (var j = 0; j < list.length - i; j++) {
          if (list[j]["amount"] < list[min]["amount"]) {
            min = j
          }
        }
        if (min !== list.length - i - 1) {
          var index = list.length - i - 1
          var t = list[min]
          list[min] = list[index]
          list[index] = t
        }
      }
    } else {
      for (var i = 0; i < list.length - 1; i++) {
        var max = 0
        for (var j = 0; j < list.length - i; j++) {
          if (list[j]["amount"] > list[max]["amount"]) {
            max = j
          }
        }
        if (max !== list.length - i - 1) {
          var index = list.length - i - 1
          var t = list[max]
          list[max] = list[index]
          list[index] = t
        }
      }
    }
    this.setData({
      orderList: list
    })
  },

  /**
   * 对数组或对象进行深拷贝，obj为对象或数组
   * @param {Object} obj 
   * @returns {Object}
   */
  deepCopy(obj) {
    var nObj = obj.constructor === Array ? [] : {}
    for (let i in obj) {
      if (typeof (obj[i]) === "object") {
        nObj[i] = this.deepCopy(obj[i])
      } else {
        nObj[i] = obj[i]
      }
    }
    return nObj
  },

  /**
   * 刷新orderList数组，将order分成提供服务和需要服务两大类
   * @param {string} type 
   */
  refreshOrderList(type) {
    if (type !== null) {
      var records = []
      if (this.data.select[0] === "selected") {
        if (this.data.classifiedRecords.hasOwnProperty(type)) {
          this.data.classifiedRecords[type].forEach(elm => {
            if (elm["service"] === "提供服务")
              records.push(elm)
          })
        }
      } else if (this.data.select[1] === "selected") {
        if (this.data.classifiedRecords.hasOwnProperty(type)) {
          this.data.classifiedRecords[type].forEach(elm => {
            if (elm["service"] === "需要服务")
              records.push(elm)
          })
        }
      }
      this.setData({
        orderList: records
      })
    }
    else {
      var records = []
      if (this.data.select[0] === "selected") {
        this.data.records.forEach(elm => {
          if (elm["service"] === "提供服务")
            records.push(elm)
        })
      } else if (this.data.select[1] === "selected") {
        this.data.records.forEach(elm => {
          if (elm["service"] === "需要服务")
            records.push(elm)
        })
      }
      this.setData({
        orderList: records
      })
    }
    this.refreshOrderCount()
  },

  /**
   * 刷新typeList数组
   * 已弃用，请勿使用，也不要删除
   * @deprecated
   */
  refreshTypeList() {
    this.setData({
      typeList: []
    })
    this.getAllRecords("test_service", "typeList", null)
  },

  /**
   * 调整显示订单类型数量
   */
  refreshTypeCount() {
    this.setData({
      typeCount: this.data.typeList.length >= 5 ? 5 : this.data.typeList.length
    })
  },

  /**
   * 调整显示订单数量
   */
  refreshOrderCount() {
    this.setData({
      orderCount: this.data.orderList.length >= 5 ? 5 : this.data.orderList.length
    })
  },

  /**
   *刷新records和classifiedRecords数组
   */
  refreshRecordList() {
    this.setData({
      records: [],
      classifiedRecords: {}
    })
    this.getAllRecords("222", "records", "type")
  },

  /**
   * 数据库获取集合collectionName中的所有记录，存入listName数组，按照fieldName属性分类
   * @param {string} collectionName 
   * @param {string} listName 
   * @param {string} fieldName 
   */ 
  getAllRecords(collectionName, listName, fieldName = null) {
    let LIMIT = 20
    wx.cloud.database().collection(collectionName).count()
      .then(res => {
        var bactchTimes = Math.ceil(res.total / LIMIT)
        for (var i = 0; i < bactchTimes; i++) {
          wx.cloud.database().collection(collectionName).skip(i * LIMIT).get()
            .then(res => {
              var records = res.data
              this.setData({
                [listName]: this.data[listName].concat(records)
              })
              //分类
              if (fieldName !== null) {
                const obj = this.classifyObjArray(records, fieldName)
                this.setData({
                  classifiedRecords: this.mergeArrayObj(this.data.classifiedRecords, obj)
                })
              }
              //刷新列表
              this.refreshOrderList(this.data.pageType)
              this.refreshTypeCount()
            })
        }
      })
  },

  /**
   * 对对象数组按照对象某一属性的属性值进行分类，分类后数组存入新的对象中，如下所示
   * [                                {
   *   对象1，对象2,                     属性值1: [对象1，对象2],
   *   对象3，对象4,        =>           属性值2: [对象3，对象4],
   *   对象5，对象6                      属性值3: [对象5，对象6],
   * ]                                }
   * 属性值为对象中同一属性的值，请以对象共有的属性作为分类属性
   * @param {Array} objArray 
   * @param {string} key
   * @returns {Object}
   */
  classifyObjArray(objArray, key) {
    var obj = {}
    objArray.forEach(elm => {
      if (elm[key] in obj) {
        obj[elm[key]].push(elm)
      } else {
        obj[elm[key]] = [elm]
      }
    })
    return obj
  },

  /**
   * 合并数组对象
   * @param {Object} targetObj 
   * @param {Object} otherObj 
   * @returns {Object}
   */
  mergeArrayObj(obj1, obj2) {
    var nObj = this.deepCopy(obj1)
    for (const key in obj2) {
      const elm = this.deepCopy(obj2[key]);
      if (nObj.hasOwnProperty(key)) {
        nObj[key] = nObj[key].concat(elm)
      } else {
        nObj[key] = elm
      }
    }
    return nObj
  },

  /**
   * 计算两地点间距离，地点1经纬度lat1、lng1，地点2经纬度lat2、lng2
   * @param {number} lat1 
   * @param {number} lng1 
   * @param {number} lat2 
   * @param {number} lng2 
   * @returns {number}
   */
  getDistance(lat1, lng1, lat2, lng2) {
    var radLat1 = this.rad(lat1);
    var radLat2 = this.rad(lat2);
    var a = radLat1 - radLat2;
    var b = this.rad(lng1) - this.rad(lng2);
    var s = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(a / 2), 2) + Math.cos(radLat1) * Math.cos(radLat2) * Math.pow(Math.sin(b / 2), 2)));
    s = s * 6378.137;
    s = Math.round(s * 10000) / 10000;
    return s * 1000
  },

  /**
   * 角度转换弧度
   * @param {number} d 
   * @returns {number}
   */
  rad(d) {
    return d * Math.PI / 180
  }
})