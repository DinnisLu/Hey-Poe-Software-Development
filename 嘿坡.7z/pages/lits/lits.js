// pages/lits/lits.js
wx.cloud.init({})
const db = wx.cloud.database()  /*云开发数据库的引入 */


const date = new Date();
const years = [];
const months = [];
const days = [];
const hours = [];
const minutes = [];
//获取年
for (let i = 2022; i <= date.getFullYear() + 0; i++) {
  years.push("" + i);
}
//获取月份
for (let i = 1; i <= 12; i++) {
  if (i < 10) {
    i = "0" + i;
  }
  months.push("" + i);
}
//获取日期
for (let i = 1; i <= 31; i++) {
  if (i < 10) {
    i = "0" + i;
  }
  days.push("" + i);
}
//获取小时
for (let i = 0; i < 24; i++) {
  if (i < 10) {
    i = "0" + i;
  }
  hours.push("" + i);
}
//获取分钟
for (let i = 0; i < 60; i++) {
  if (i < 10) {
    i = "0" + i;
  }
  minutes.push("" + i);
}






Page({

  /**
   * 页面的初始数据
   */
  data: {
    isSelect: false,//展示类型？
    types: ['旧货交易', '校外代购', '学校公益专区', '线上类', '兼职专区', '综合服务'],
    type: "",
    time: '',
    multiArray: [years, months, days, hours, minutes],
    multiIndex: [0, 9, 16, 10, 17],
    choose_year: '',
    array: ['需要服务', '提供服务'],



  },


  // 验证手机号码=11位，且只能是数字
  phoneChange(event) {
    // let phone = event.detail.value || event;
    let phone = this.phones(event.detail.value);
    this.setData({
      phone: phone
    })
    return phone
  },
  phones(val) {
    let num = val.toString(); //先转换成字符串类型
    num = num.replace(/\D/g, '')
    return num
  },
  // 手机号码输入完点击完成时验证
  phoneconfirm(phone) {
    if (!/^1[3456789]\d{9}$/.test(phone) || phone.length < 11) {
      return false
    } else {
      return true
    }
  },




  select: function () {
    var isSelect = this.data.isSelect
    this.setData({ isSelect: !isSelect })
  },
  //点击下拉框选项，选中并隐藏下拉框
  getType: function (e) {
    let value = e.currentTarget.dataset.type
    this.setData({
      type: value,
      isSelect: false,
    })
  },



  // check:function(e)
  // { 
  //   console.log(e.detail.value)
  //   this.setData({
  //   phone: e.detail.value
  // })
  //   if (phone == '') {
  //     wx.showToast({
  //     title: '请填写电话号码',
  //     icon: 'none',
  //     duration: 1500
  //   })
  //   return false
  // }
  // },




  submitForm(res) {              /*数据库用户信息集合*/
    console.log("in")
    wx.showLoading({
      title: '数据提交中......',
    })
    var { wxchat, type, service, phone, detail, amount, name, time, goods, oprice, tprice, gmgoods, place, require, organization, publictime } = res.detail.value;
    //var resVlu=res.detail.value
    console.log(wxchat, type, service, phone, detail, amount, name, time, goods, oprice, tprice, gmgoods, place, require, organization, publictime)
    wx.startLocationUpdate({
      success: (res) => { },
    })

    if (this.Empty(phone) || this.Empty(name) || this.Empty(detail) || this.Empty(service)) {
      wx.showToast({
        icon: "error",
        title: '请输入完整信息',
        duration: 5000,
      })
      wx.hideLoading({
        success: (res) => { },
      })
      return
    }

    if (!this.phoneconfirm(phone)) {
      wx.showToast({
        title: '您输入的手机号码有误',
        icon: 'none',
        duration: 2000
      })
      return
    }

    wx.onLocationChange((result) => {
      db.collection("222").add({
        data: {
          type: this.data.type,
          wxchat: wxchat,
          service: service,
          phone: phone,
          detail: detail,
          amount: amount,
          name: name,
          time: time,
          goods: goods,   //交易商品
          oprice: oprice,  //商品原价格
          tprice: tprice,  //出售价格
          gmgoods: gmgoods, //购买物品
          place: place,   //购买地点
          require: require,      //兼职要求
          organization: organization,   //发布组织
          publictime: publictime,    //公益时长
          latitude: result.latitude,
          longitude: result.longitude

        }


      }).then(res => {
        wx.switchTab({
          url: '../map/map',
        })
        wx.hideLoading({
          success: (res) => { },
        })
      })
      wx.offLocationChange()
      wx.stopLocationUpdate({
        success: (res) => { },
      })
    })
  },

  Empty: function (value) {
    return value == ""
  },






  nextPage: function () {
    wx.navigateTo({
      url: '/pages/map/map',
    })
  },




  bindPickerChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      service: e.detail.value
    })
  },


  onLoad: function () {
    //设置默认的年份
    this.setData({
      choose_year: this.data.multiArray[0][0]
    })
  },
  //获取时间日期
  bindMultiPickerChange: function (e) {
    // console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      multiIndex: e.detail.value
    })
    const index = this.data.multiIndex;
    const year = this.data.multiArray[0][index[0]];
    const month = this.data.multiArray[1][index[1]];
    const day = this.data.multiArray[2][index[2]];
    const hour = this.data.multiArray[3][index[3]];
    const minute = this.data.multiArray[4][index[4]];
    // console.log(`${year}-${month}-${day}-${hour}-${minute}`);
    this.setData({
      time: year + '-' + month + '-' + day + ' ' + hour + ':' + minute
    })
    // console.log(this.data.time);
  },
  //监听picker的滚动事件
  bindMultiPickerColumnChange: function (e) {
    //获取年份
    if (e.detail.column == 0) {
      let choose_year = this.data.multiArray[e.detail.column][e.detail.value];
      console.log(choose_year);
      this.setData({
        choose_year
      })
    }
    //console.log('修改的列为', e.detail.column, '，值为', e.detail.value);
    if (e.detail.column == 1) {
      let num = parseInt(this.data.multiArray[e.detail.column][e.detail.value]);
      let temp = [];
      if (num == 1 || num == 3 || num == 5 || num == 7 || num == 8 || num == 10 || num == 12) { //判断31天的月份
        for (let i = 1; i <= 31; i++) {
          if (i < 10) {
            i = "0" + i;
          }
          temp.push("" + i);
        }
        this.setData({
          ['multiArray[2]']: temp
        });
      } else if (num == 4 || num == 6 || num == 9 || num == 11) { //判断30天的月份
        for (let i = 1; i <= 30; i++) {
          if (i < 10) {
            i = "0" + i;
          }
          temp.push("" + i);
        }
        this.setData({
          ['multiArray[2]']: temp
        });
      } else if (num == 2) { //判断2月份天数
        let year = parseInt(this.data.choose_year);
        console.log(year);
        if (((year % 400 == 0) || (year % 100 != 0)) && (year % 4 == 0)) {
          for (let i = 1; i <= 29; i++) {
            if (i < 10) {
              i = "0" + i;
            }
            temp.push("" + i);
          }
          this.setData({
            ['multiArray[2]']: temp
          });
        } else {
          for (let i = 1; i <= 28; i++) {
            if (i < 10) {
              i = "0" + i;
            }
            temp.push("" + i);
          }
          this.setData({
            ['multiArray[2]']: temp
          });
        }
      }
      console.log(this.data.multiArray[2]);
    }
    var data = {
      multiArray: this.data.multiArray,
      multiIndex: this.data.multiIndex
    };
    data.multiIndex[e.detail.column] = e.detail.value;
    this.setData(data);
  },






  /**
   * 生命周期函数--监听页面加载
   */

  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})


